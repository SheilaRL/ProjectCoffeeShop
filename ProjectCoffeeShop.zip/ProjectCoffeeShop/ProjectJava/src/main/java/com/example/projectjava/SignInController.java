package com.example.projectjava;

import Clases.User;
import Clases.UserLists;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

/**
 * Class to store information about the signIn page.
 * @author sheilaRodríguez.
 */
public class SignInController implements Initializable
{
    @FXML
    public TextField textFieldName;
    @FXML
    public TextField textFieldSurname;
    @FXML
    public TextField textFieldEmail;
    @FXML
    public TextField textFieldPassword;
    @FXML
    public TextField textFieldPhoneNumber;
    @FXML
    public TextField textFieldAddress;
    @FXML
    public RadioButton radioButtonEmployee;
    @FXML
    public RadioButton radioButtonClient;
    @FXML
    public Button buttonSignIn;
    @FXML
    public Label labelAdress;
    @FXML
    public Label labelPhone;
    @FXML
    public Label labelPasswd;
    @FXML
    public Label labelEmail;
    @FXML
    public Label labelSurname;
    @FXML
    public Label labelName;

    private UserLists userLists;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {
        userLists = new UserLists();
        userLists.loadUsers();
    }

    public void setUserLists(UserLists userLists)
    {
        this.userLists = userLists;
    }

    public void signIn(ActionEvent event)
    {
        String name, surname, email, password, address;
        int phoneNumber;

        name = textFieldName.getText();
        surname = textFieldSurname.getText();
        email = textFieldEmail.getText();
        password = textFieldPassword.getText();
        address = textFieldAddress.getText();
        phoneNumber = Integer.parseInt(textFieldPhoneNumber.getText());

        if (name.isEmpty() || surname.isEmpty() || email.isEmpty() || password.isEmpty()||
                address.isEmpty() || textFieldPhoneNumber.getText().isEmpty())
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please, fill all the information");
            alert.showAndWait();
        }

        User newUser = new User(name, surname, email, password, phoneNumber, address);
        userLists.addUsers(newUser);
        userLists.saveUsers();

        Stage stage = (Stage) buttonSignIn.getScene().getWindow();
        stage.close();
        removeFields();
    }


    public void removeFields()
    {
        textFieldName.clear();
        textFieldSurname.clear();
        textFieldEmail.clear();
        textFieldAddress.clear();
        textFieldPhoneNumber.clear();
        textFieldPassword.clear();
    }

    public void chooseEmployee(ActionEvent event)
    {

    }

    public void chooseClient(ActionEvent event)
    {
    }
}
