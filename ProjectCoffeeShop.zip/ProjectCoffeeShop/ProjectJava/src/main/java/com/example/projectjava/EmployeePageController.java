package com.example.projectjava;

import Clases.User;
import Clases.UserLists;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

/**
 * Class to store information about the employee page.
 * @author sheilaRodríguez
 */
public class EmployeePageController implements Initializable
{
    public Button reservationsButton;
    public AnchorPane buttonReservation;
    public Button buttonOrders;
    public Button buttonStock;
    public Button payments;
    public Label welcomePage;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {

    }

    /**
     * Actions events to move to another page. In this case,to move to another option.
     * @param event
     * @throws IOException
     */
    public void makeReservation(ActionEvent event) throws IOException
    {
        FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("Reservations.fxml"));
        Scene scene = new Scene(loader.load());
        Stage stage = new Stage();
        stage.setTitle("Reservations");
        stage.setScene(scene);
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.show();
    }


    public void seeOrders(ActionEvent event) throws IOException
    {
        FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("Orders.fxml"));
        Scene scene = new Scene(loader.load());
        Stage stage = new Stage();
        stage.setTitle("Orders");
        stage.setScene(scene);
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.show();
    }


    public void seeStock(ActionEvent event) throws IOException
    {
        FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("Stock.fxml"));
        Scene scene = new Scene(loader.load());
        Stage stage = new Stage();
        stage.setTitle("Stock");
        stage.setScene(scene);
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.show();
    }

    public void makePayments(ActionEvent event) throws IOException
    {
        FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("EmployeePayment.fxml"));
        Scene scene = new Scene(loader.load());
        Stage stage = new Stage();
        stage.setTitle("Payments");
        stage.setScene(scene);
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.show();
    }

}
