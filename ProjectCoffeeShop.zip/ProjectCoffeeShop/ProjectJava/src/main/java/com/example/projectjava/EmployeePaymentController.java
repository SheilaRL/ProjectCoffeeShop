package com.example.projectjava;

import Clases.Product;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.util.StringConverter;

import java.net.URL;
import java.util.ResourceBundle;

public class EmployeePaymentController implements Initializable
{
    public TextField textBoxQuantity;
    public TextField textBoxCash;
    public Button buttonPay;
    public Button buttonAdd;
    public Button buttonDelete;
    public TableView <Product> tableView;
    public TextField textBoxPrice;
    public TextField textBoxID;
    public TextField textBoxName;
    public TextField textBoxPayment;
    public TextField textBoxDevolution;
    public TextField textBoxPrice1;
    public ObservableList<Product> products;
    public TableColumn <Product, Integer> columID;
    public TableColumn <Product, String> columName;
    public TableColumn <Product, Double> columPrice;
    public TableColumn <Product, Integer> columQuantity;
    public TableColumn <Product, Double> columSubtotal;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {
       products = FXCollections.observableArrayList();

       columID.setCellValueFactory(new PropertyValueFactory<Product, Integer>("idProduct"));
       columName.setCellValueFactory(new PropertyValueFactory<Product, String>("productName"));
       columPrice.setCellValueFactory(new PropertyValueFactory<Product, Double>("price"));
       columQuantity.setCellValueFactory(new PropertyValueFactory<Product, Integer>("quantity"));
       columSubtotal.setCellValueFactory(cellData -> new SimpleDoubleProperty(cellData.getValue().
               getPrice() * cellData.getValue().getQuantity()).asObject());

       tableView.setItems(products);
       textBoxDevolution.setOnKeyReleased(this::calculateDevolution);

       buttonPay.setOnAction(this:: pay);
    }

    public void addProduct(ActionEvent event)
    {
        try
        {
            int id = Integer.parseInt(textBoxID.getText());
            String name = textBoxName.getText();
            double price = Double.parseDouble(textBoxPrice.getText());
            int quantity = Integer.parseInt(textBoxQuantity.getText());


            Product product = new Product(id, name, price, quantity);
            products.add(product);

            calculateTotal();
            clear();

        } catch (NumberFormatException e)
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Error filling colums");
        }

    }

    public void deleteProduct(ActionEvent event)
    {
        int index = tableView.getSelectionModel().getSelectedIndex();
        if (index >= 0)
        {
            tableView.getItems().remove(index);
            calculateTotal();
        }
    }

    public void calculateTotal()
    {
        double total = 0;

        for (Product product : products)
        {
            total += product.getPrice() * product.getQuantity();
        }

        textBoxPayment.setText(String.valueOf(total));

    }

    public void calculateDevolution(KeyEvent event)
    {
        try
        {
            double totalPayment = Double.parseDouble(textBoxPayment.getText());
            double devolution = Double.parseDouble(textBoxDevolution.getText());
            double cash = devolution - totalPayment;

            textBoxCash.setText(String.format("%.2f", cash));

        } catch (NumberFormatException e)
        {
            textBoxCash.setText("0.00");
        }
    }

    public void clear()
    {
        textBoxID.clear();
        textBoxName.clear();
        textBoxPrice.clear();
        textBoxQuantity.clear();
        textBoxPrice1.clear();
    }

    public void pay(ActionEvent event)
    {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setContentText("Successful payment. Thanks and come back soon");
        alert.showAndWait();
    }

    public void selectCombobox(ActionEvent event)
    {

    }

}
