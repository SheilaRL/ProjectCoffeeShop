package com.example.projectjava;

import Clases.Order;
import Clases.OrderList;
import Clases.Reservation;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.ResourceBundle;

public class OrdersController implements Initializable {
    public TableView <Order> tableView;
    public TableColumn <Order, Integer> columNumber;
    public TableColumn <Order, Integer> columTable;
    public TableColumn <Order, String> columOrder;
    public TextField textBoxNumber;
    public TextField textBoxTable;
    public TextField textBoxOrder;
    public Button buttonAdd;
    public Button buttonModify;
    public Button buttonDelete;
    public ObservableList <Order> orders;
    public OrderList orderList;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {
        orderList = new OrderList();
        orders = FXCollections.observableArrayList(orderList.getOrder());
        tableView.setItems(orders);

        columNumber.setCellValueFactory(new PropertyValueFactory<>("orderNumber"));
        columTable.setCellValueFactory(new PropertyValueFactory<>("mesa"));
        columOrder.setCellValueFactory(new PropertyValueFactory<>("order"));

        updateTableView();

        tableView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) ->
        {
            loadOrder();
        });
    }

    public void addOrder(ActionEvent event)
    {
        try
        {
            int orderNumber = Integer.parseInt(textBoxNumber.getText());
            int table = Integer.parseInt(textBoxTable.getText());
            String orders = textBoxOrder.getText();

            Order orderTable = new Order(orderNumber, table, orders);
            orderList.addOrder(orderTable);
            updateTableView();
            clear();
        } catch (NumberFormatException e)
        {
            throw new RuntimeException(e);
        }

    }

    public void loadOrder()
    {
        Order chooseOrder = tableView.getSelectionModel().getSelectedItem();

        if (chooseOrder != null)
        {
            textBoxNumber.setText(String.valueOf(chooseOrder.getOrderNumber()));
            textBoxTable.setText(String.valueOf(chooseOrder.getMesa()));
            textBoxOrder.setText(chooseOrder.getOrder());
        }
    }

    public void modifyOrders(ActionEvent event)
    {
        Order selectOrder = tableView.getSelectionModel().getSelectedItem();

        if (selectOrder != null)
        {
            try
            {
                int orderNumber = Integer.parseInt(textBoxNumber.getText());
                int table = Integer.parseInt(textBoxTable.getText());
                String order = textBoxOrder.getText();

                selectOrder.setOrderNumber(orderNumber);
                selectOrder.setMesa(table);
                selectOrder.setOrder(order);

                orderList.saveOrders();
                updateTableView();
                clear();

            } catch (NumberFormatException e)
            {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("Invalid format");
                alert.show();
            }
        }

        else
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("No order selected to modify");
            alert.show();
        }
    }

    public void deleteOrder(ActionEvent event)
    {
        Order order = tableView.getSelectionModel().getSelectedItem();

        if (order != null)
        {
            orderList.deleteOrder(order);
            updateTableView();
        }

        else
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Choose one order to delete");
            alert.show();
        }
    }

    public void updateTableView()
    {
        orders.setAll(orderList.getOrder());
        tableView.refresh();
    }

    public void clear()
    {
        textBoxNumber.clear();
        textBoxOrder.clear();
        textBoxTable.clear();
    }
}
