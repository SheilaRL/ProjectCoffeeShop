package com.example.projectjava;
import Clases.Reservation;
import Clases.ReservationList;
import Clases.Stock;
import Clases.StockList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

public class StockController implements Initializable
{
    public TableView <Stock> tableView;
    public TableColumn <Stock, Integer> columCode;
    public TableColumn <Stock, String> columName;
    public TableColumn <Stock, Integer> columQuantity;
    public TableColumn <Stock, String> columState;
    public TextField textBoxCode;
    public TextField textBoxName;
    public TextField textBoxQuantity;
    public TextField textBoxState;
    public Button buttonAdd;
    public Button buttonDelete;
    public ObservableList <Stock> stocks;
    public StockList stockList;
    public TextField textBoxSearch;


    /**
     * Method to initialize the stockList and fill the columns of the tableview
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {
        stockList = new StockList();
        stocks = FXCollections.observableArrayList(stockList.getStockList());
        tableView.setItems(stocks);

        columCode.setCellValueFactory(new PropertyValueFactory<>("productCode"));
        columName.setCellValueFactory(new PropertyValueFactory<>("productName"));
        columQuantity.setCellValueFactory(new PropertyValueFactory<>("quantityAvailable"));
        columState.setCellValueFactory(new PropertyValueFactory<>("state"));
    }

    /**
     * Method to add stock to the tableview by clicking the add button
     */
    public void addStock(ActionEvent event)
    {
        try
        {
            int productCode = Integer.parseInt(textBoxCode.getText());
            String productName = textBoxName.getText();
            int quantity = Integer.parseInt(textBoxQuantity.getText());
            String state = textBoxState.getText();

            Stock stock = new Stock(productCode, productName, quantity, state);
            stockList.addStock(stock);
            updateTableView();
            clear();

        } catch (NumberFormatException e)
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please enter valid information.");
            alert.show();
        }


    }

    /**
     * Method to delete stock by clicking the delete buttom
     */
    public void deleteStock(ActionEvent event)
    {
        Stock stock = tableView.getSelectionModel().getSelectedItem();

        if (stock != null)
        {
            stockList.deleteStock(stock);
            updateTableView();
        }

        else
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Choose stock to delete");
            alert.show();
        }
    }

    /**
     * Method to load stock in the tableView
     */
    public void loadStock()
    {
        Stock selectStock = tableView.getSelectionModel().getSelectedItem();

        if (selectStock != null)
        {
            textBoxCode.setText(String.valueOf(selectStock.getProductCode()));
            textBoxName.setText(selectStock.getProductName());
            textBoxQuantity.setText(String.valueOf(selectStock.getQuantityAvailable()));
            textBoxState.setText(selectStock.getState());
        }
    }

    /**
     * Method to update the tableview once the information is added
     */
    public void updateTableView()
    {
        stocks.setAll(stockList.getStockList());
        tableView.refresh();
    }

    /**
     * Method to clear the fields
     */
    public void clear()
    {
        textBoxName.clear();
        textBoxCode.clear();
        textBoxQuantity.clear();
        textBoxState.clear();
    }

    /**
     * Method to search stock by name in the textbox
     */
    public void searchStock(ActionEvent event)
    {
        String name = textBoxSearch.getText().trim();

        if (name.isEmpty())
        {
            updateTableView();
        }

        else
        {
            List<Stock> filter = filterByName(name);
            stocks.setAll(filter);
        }
    }

    /**
     * Method to search in the texfield by name and filter by name
     */
    public List<Stock> filterByName (String name)
    {
        return stockList.getStockList().stream()
                .filter(stock -> stock.getProductName().equalsIgnoreCase(name))
                .collect(Collectors.toList());
    }
}
