package com.example.projectjava;
import Clases.Reservation;
import Clases.ReservationList;
import Clases.Stock;
import Clases.StockList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.ResourceBundle;

public class StockController implements Initializable
{
    public TableView <Stock> tableView;
    public TableColumn <Stock, Integer> columCode;
    public TableColumn <Stock, String> columName;
    public TableColumn <Stock, Integer> columQuantity;
    public TableColumn <Stock, String> columState;
    public TextField textBoxCode;
    public TextField textBoxName;
    public TextField textBoxQuantity;
    public TextField textBoxState;
    public Button buttonAdd;
    public Button buttonDelete;
    public ObservableList <Stock> stocks;
    public StockList stockList;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {
        stockList = new StockList();
        stocks = FXCollections.observableArrayList(stockList.getStockList());
        tableView.setItems(stocks);

        columName.setCellValueFactory(new PropertyValueFactory<>("productName"));
        columCode.setCellValueFactory(new PropertyValueFactory<>("productCode"));
        columQuantity.setCellValueFactory(new PropertyValueFactory<>("quantityAvailable"));
        columState.setCellValueFactory(new PropertyValueFactory<>("state"));

        tableView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) ->
                {
                    loadStock();
                });
    }

    public void addStock(ActionEvent event)
    {
        try
        {
            int productCode = Integer.parseInt(textBoxCode.getText());
            String productName = textBoxName.getText();
            int quantity = Integer.parseInt(textBoxQuantity.getText());
            String state = textBoxState.getText();

            Stock stock = new Stock(productCode, productName, quantity, state);
            stockList.addStock(stock);
            updateTableView();
            clear();
        } catch (NumberFormatException e)
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please enter valid information.");
            alert.show();
        }


    }

    public void deleteStock(ActionEvent event)
    {
        Stock stock = tableView.getSelectionModel().getSelectedItem();

        if (stock != null)
        {
            stockList.deleteStock(stock);
            updateTableView();
        }

        else
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Choose stock to delete");
            alert.show();
        }
    }

    public void loadStock()
    {
        Stock selectStock = tableView.getSelectionModel().getSelectedItem();

        if (selectStock != null)
        {
            textBoxCode.setText(String.valueOf(selectStock.getProductCode()));
            textBoxName.setText(selectStock.getProductName());
            textBoxQuantity.setText(String.valueOf(selectStock.getQuantityAvailable()));
            textBoxState.setText(selectStock.getState());
        }
    }

    public void updateTableView()
    {
        stocks.setAll(stockList.getStockList());
        tableView.refresh();
    }

    public void clear()
    {
        textBoxName.clear();
        textBoxCode.clear();
        textBoxQuantity.clear();
        textBoxState.clear();
    }
}
