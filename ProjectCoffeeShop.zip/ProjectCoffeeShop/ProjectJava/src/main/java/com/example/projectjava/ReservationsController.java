package com.example.projectjava;
import Clases.Reservation;
import Clases.ReservationList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class ReservationsController implements Initializable
{

    public TextField textBoxName;
    public TextField textBoxHour;
    public DatePicker datePicker;
    public TextField textBoxPeople;
    public TextField textBoxPhone;
    public Button buttonAdd;
    public Button buttonDelete;
    public TableColumn <Reservation,String> columName;
    public TableColumn <Reservation,LocalDate> columDate;
    public TableColumn <Reservation, LocalTime> columHour;
    public TableColumn <Reservation, Integer> columPeople;
    public TableColumn <Reservation, String> columPhone;
    public TableView <Reservation> tableView;

    public ObservableList<Reservation> reservations;

    public ReservationList reservationList;
    public TextField searchField;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {
        reservationList = new ReservationList();
        reservations = FXCollections.observableArrayList(reservationList.getReservations());
        tableView.setItems(reservations);

        columName.setCellValueFactory(new PropertyValueFactory<>("name"));
        columDate.setCellValueFactory(new PropertyValueFactory<>("reservationDate"));
        columHour.setCellValueFactory(new PropertyValueFactory<>("reservationHour"));
        columPeople.setCellValueFactory(new PropertyValueFactory<>("numberOfPeople"));
        columPhone.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));

    }

    public void addButton(ActionEvent event)
    {
        String name = textBoxName.getText();
        LocalTime reservationHour = LocalTime.parse(textBoxHour.getText());
        LocalDate reservationDate =datePicker.getValue();
        int numberPeople = Integer.parseInt(textBoxPeople.getText());
        int phoneNumber = Integer.parseInt(textBoxPhone.getText());

        Reservation reservation = new Reservation(name,reservationHour,reservationDate,numberPeople,phoneNumber);
        reservationList.addReservations(reservation);
        updateTableView();
        clear();
    }


    public void deleteButton(ActionEvent event)
    {
        Reservation reservation = tableView.getSelectionModel().getSelectedItem();

        if (reservation != null)
        {
            reservationList.deleteReservations(reservation);
            updateTableView();
        }

        else
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Choose one reservation to delete");
            alert.show();
        }
    }

    public void updateTableView()
    {
        reservations.setAll(reservationList.getReservations());
    }

    public void clear()
    {
        textBoxName.clear();
        textBoxHour.clear();
        textBoxPeople.clear();
        textBoxPhone.clear();
    }

    public void searchInformation(ActionEvent event)
    {
        String name = searchField.getText().trim();

        if (name.isEmpty())
        {
            updateTableView();
        }

        else
        {
            List<Reservation> filter = filterByName(name);
            reservations.setAll(filter);
        }
    }

    public List<Reservation> filterByName (String name)
    {
        return reservationList.getReservations().stream()
                .filter(reservation -> reservation.getName().equalsIgnoreCase(name))
                .collect(Collectors.toList());
    }
}
