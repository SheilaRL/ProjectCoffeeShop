package com.example.projectjava;

import Clases.User;
import Clases.UserLists;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Modality;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

/**
 * Class to store information about the login page.
 * @author sheilaRodríguez.
 */
public class LogInController implements Initializable
{
    public TextField textBoxName;
    public TextField textBoxPasswd;
    public Button button1;
    public Button buttonEmployee;
    public Button buttonClient;
    private TextField userName;
    @FXML
    private RadioButton radioButton1;
    @FXML
    private RadioButton radioButton2;
    @FXML
    private Label labelName, labelPassword;
    private UserLists userLists = new UserLists();



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {
        userLists.loadUsers();
        //System.out.println("Users loaded: " + userLists.getUserList());
    }

    public UserLists getUserListsLogIn()
    {
        return userLists;
    }

    public void setUserLists(UserLists userLists)
    {
        userLists = userLists;
    }

    public void enterButton(ActionEvent event) throws IOException
    {


    }


    public void enterEmployeePage(ActionEvent event) throws IOException
    {
        String email = textBoxName.getText().trim().replaceAll("'", "");
        String password = textBoxPasswd.getText();

        //System.out.println("Entered email: " + email + "'");
        //System.out.println("Entered password: " + password);

        User user = checkUser(email, password);

        if (user != null)
        {
            try
            {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("EmployeePage.fxml"));
                Scene scene = new Scene(loader.load());
                Stage stage = new Stage();
                stage.setScene(scene);
                stage.setTitle("Employee page");
                stage.show();

                Stage thisWindow = (Stage) textBoxName.getScene().getWindow();
                thisWindow.close();

            } catch (IOException e)
            {
                throw new RuntimeException(e);
            }
        }

        else
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Login Error");
            alert.setHeaderText("Invalid Credentials");
            alert.setContentText("Please, enter correct username and password");
            alert.showAndWait();
        }

    }

    public User checkUser(String email, String password)
    {
        for (User user : userLists.getUserList())
        {
            //System.out.println("Checking email: " + user.getEmail() + ", " + user.getPassword());
            //System.out.println("Entered user: " + email + ", " + password);

            if (user.getEmail().equals(email) && user.getPassword().equals(password))
            {
                //System.out.println("User authenticated: " + user);
                return user;
            }
        }
        //System.out.println("User not found for email: " + " and password: " + password);

        return null;
    }

    public void enterClientPage(ActionEvent event) throws IOException
    {

    }

}
