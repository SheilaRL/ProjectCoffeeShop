package com.example.projectjava;

import Clases.User;
import Clases.UserLists;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Modality;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

/**
 * Class to store information about the login page.
 * @author sheilaRodríguez.
 */
public class LogInController implements Initializable
{
    public TextField textBoxName;
    public TextField textBoxPasswd;
    public Button button1;
    public Button buttonEmployee;
    public Button buttonClient;
    private TextField userName;
    @FXML
    private RadioButton radioButton1;
    @FXML
    private RadioButton radioButton2;
    @FXML
    private Label labelName, labelPassword;
    private UserLists userLists = new UserLists();



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {
        userLists.loadUsers();
    }

    /**
     * Method to return the list of users
     */
    public UserLists getUserListsLogIn()
    {
        return userLists;
    }

    public void setUserLists(UserLists userLists)
    {
        userLists = userLists;
    }

    /**
     * Method to log in and enter the employee page
     */
    public void enterEmployeePage(ActionEvent event) throws IOException
    {
        String email = textBoxName.getText().trim().replaceAll("'", "");
        String password = textBoxPasswd.getText();

        User user = checkUser(email, password);

        if (user != null)
        {
            try
            {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("EmployeePage.fxml"));
                Scene scene = new Scene(loader.load());
                Stage stage = new Stage();
                stage.setScene(scene);
                stage.setTitle("Employee page");
                stage.show();

                Stage thisWindow = (Stage) textBoxName.getScene().getWindow();
                thisWindow.close();

            } catch (IOException e)
            {
                throw new RuntimeException(e);
            }
        }

        else
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Login Error");
            alert.setHeaderText("Invalid Credentials");
            alert.setContentText("Please, enter correct username and password");
            alert.showAndWait();
        }

    }

    /**
     * Method to check if the user is in the userList
     */
    public User checkUser(String email, String password)
    {
        for (User user : userLists.getUserList())
        {

            if (user.getEmail().equals(email) && user.getPassword().equals(password))
            {
                return user;
            }
        }

        return null;
    }

}
