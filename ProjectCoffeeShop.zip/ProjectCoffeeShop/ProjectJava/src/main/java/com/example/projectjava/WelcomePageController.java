package com.example.projectjava;
import Clases.UserLists;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;

/**
 * Class to store information about the welcome page.
 * @author sheilaRodríguez.
 */
public class WelcomePageController implements Initializable
{
    @FXML
    private Button ButtonLogIn;
    @FXML
    private Button ButtonSignIn;
    @FXML
    private Pane welcomePanel;
    @FXML
    private ImageView imageView;
    private UserLists userLists;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {
        //Image image = new Image(getClass().getResourceAsStream("/src/Photos/b2da1fccadfed726bc47caa8b5c71499-removebg-preview.png"));
        //imageView.setImage(image);

    }

    /**
     * Function to choose between logIn or signIn
     */
    public void logIn(ActionEvent actionEvent) throws IOException
    {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("LogInPage.fxml"));
        Scene scene = new Scene(loader.load());
        Stage stage = new Stage();
        stage.setTitle("Log in");
        stage.setScene(scene);
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.showAndWait();
    }

    public void signIn(ActionEvent actionEvent) throws IOException
    {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("SignInPage.fxml"));
        Scene scene = new Scene(loader.load());
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.setTitle("SignIn");
        stage.show();
    }
}
