module com.example.projectjava {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.projectjava to javafx.fxml;
    opens Clases to javafx.base;
    exports com.example.projectjava;
}