package Clases;

import javafx.scene.control.Alert;

import java.io.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class StockList
{
    private List<Stock> stockList;
    private final String path = "src/stock.txt";

    public StockList()
    {
        stockList = new ArrayList<>();
        loadStock();
    }

    public List<Stock> getStockList()
    {
        return stockList;
    }

    public void addStock(Stock stock)
    {
        stockList.add(stock);
        saveStock();
    }

    public void deleteStock(Stock stock)
    {
        stockList.remove(stock);
        saveStock();
    }

    public void loadStock()
    {
        try(BufferedReader r = new BufferedReader(new FileReader(path)))
        {
            String line;
            while((line = r.readLine()) != null)
            {
                String [] parts = line.split(",");
                if (parts.length == 4)
                {
                    Stock stock = new Stock(Integer.parseInt(parts[0]), parts[1], Integer.parseInt(parts[2]),
                            parts[3]);

                    stockList.add(stock);
                }
                else
                {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                }
            }

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void saveStock()
    {
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(path)))
        {
            for (Stock stock : stockList)
            {
                bw.write(stock.getProductCode() + "," + stock.getProductName() + "," +
                        stock.getQuantityAvailable()+ "," + stock.getState()    );
                bw.newLine();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
