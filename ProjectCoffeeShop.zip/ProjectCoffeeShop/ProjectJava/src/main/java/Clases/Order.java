package Clases;

/**
 * Class to store information about orders.
 * @author sheilaRodríguez.
 */
public class Order
{
    private int orderNumber;
    private int mesa;
    private String order;

    public Order(int orderNumber, int mesa, String order) {
        this.orderNumber = orderNumber;
        this.mesa = mesa;
        this.order = order;
    }


    public int getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(int orderNumber) {
        this.orderNumber = orderNumber;
    }

    public int getMesa() {
        return mesa;
    }

    public void setMesa(int mesa) {
        this.mesa = mesa;
    }

    public String getOrder() {
        return order;
    }

    public void setOrder(String order) {
        this.order = order;
    }
}
