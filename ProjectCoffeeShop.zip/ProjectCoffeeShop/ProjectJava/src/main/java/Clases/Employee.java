package Clases;

/**
 * Class to store information about employees.
 * @author sheilaRodríguez.
 */
public class Employee extends User
{


    public Employee(String name, String surname, String email, String password, String phoneNumber,
                    String adress) {
        super(name, surname, email, password, phoneNumber, adress);
    }
}
