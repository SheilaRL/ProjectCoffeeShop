package Clases;

/**
 * Class to store information about employees.
 * @author sheilaRodríguez.
 */
public class Employee extends User
{


    public Employee(String name, String surname, String email, String password, int phoneNumber,
                    String adress /* boolean isClient, boolean isEmployee*/) {
        super(name, surname, email, password, phoneNumber, adress/*isClient, isEmployee*/);
    }
}
