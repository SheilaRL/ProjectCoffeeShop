package Clases;

import javafx.scene.control.Alert;

import java.io.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class OrderList
{
    List<Order> orderList;

    private final String path = "src/orders.txt";

    public OrderList()
    {
        orderList = new ArrayList<>();
        loadOrders();
    }

    public List<Order> getOrder()
    {
        return orderList;
    }

    public void addOrder(Order order)
    {
        orderList.add(order);
        saveOrders();
    }

    public void deleteOrder(Order order)
    {
        orderList.remove(order);
        saveOrders();
    }

    public void loadOrders()
    {
        try(BufferedReader r = new BufferedReader(new FileReader(path)))
        {
            String line;
            while((line = r.readLine()) != null)
            {
                String [] parts = line.split(",");
                if (parts.length == 3)
                {
                    Order order = new Order(Integer.parseInt(parts[0]),
                            Integer.parseInt(parts[1]), parts[2]);

                    orderList.add(order);
                }
                else
                {
                    /*Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setContentText("Error loading orders.");
                    alert.show();*/
                }
            }

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void saveOrders()
    {
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(path)))
        {
            for (Order order : orderList)
            {
                bw.write(order.getOrderNumber() + "," + order.getMesa() + "," + order.getOrder());
                bw.newLine();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


}
