package Clases;

import javafx.scene.control.Alert;

import java.io.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class ReservationList
{
    private List<Reservation> reservationList;
    private final String path = "src/reservations.txt";

    public ReservationList()
    {
        reservationList = new ArrayList<>();
        loadReservations();
    }

    public List<Reservation> getReservations()
    {
        return reservationList;
    }

    public void addReservations(Reservation reservation)
    {
        reservationList.add(reservation);
        saveReservations();
    }

    public void deleteReservations(Reservation reservation)
    {
        reservationList.remove(reservation);
        saveReservations();
    }

    public void loadReservations()
    {
        try(BufferedReader r = new BufferedReader(new FileReader(path)))
        {
            String line;
            while((line = r.readLine()) != null)
            {
                String [] parts = line.split(",");
                if (parts.length == 5)
                {
                    Reservation reservation = new Reservation(parts[0], LocalTime.parse(parts[1]),
                            LocalDate.parse(parts[2]), Integer.parseInt(parts[3]), Integer.parseInt(parts[4]));

                    reservationList.add(reservation);
                }
                else
                {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                }
            }

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void saveReservations()
    {
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(path)))
        {
            for (Reservation reservation : reservationList)
            {
                bw.write(reservation.getName() + "," + reservation.getReservationHour() + "," +
                        reservation.getReservationDate() + "," + reservation.getNumberOfPeople() + "," +
                        reservation.getPhoneNumber());
                bw.newLine();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}
