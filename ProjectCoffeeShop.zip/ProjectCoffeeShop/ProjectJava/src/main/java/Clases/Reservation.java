package Clases;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

/**
 * Class to store information about reservations.
 * @author sheilaRodríguez.
 */
public class Reservation
{
    /**
     * Atributes with constructor and getters and setters
     */
    private String name;
    private LocalTime reservationHour;
    private LocalDate reservationDate;
    private int numberOfPeople;
    private int phoneNumber;

    public Reservation(String name, LocalTime reservationHour, LocalDate reservationDate, int numberOfPeople, int phoneNumber) {
        this.name = name;
        this.reservationHour = reservationHour;
        this.reservationDate = reservationDate;
        this.numberOfPeople = numberOfPeople;
        this.phoneNumber = phoneNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalTime getReservationHour() {
        return reservationHour;
    }

    public void setReservationHour(LocalTime reservationHour) {
        this.reservationHour = reservationHour;
    }

    public LocalDate getReservationDate() {
        return reservationDate;
    }

    public void setReservationDate(LocalDate reservationDate) {
        this.reservationDate = reservationDate;
    }

    public int getNumberOfPeople() {
        return numberOfPeople;
    }

    public void setNumberOfPeople(int numberOfPeople) {
        this.numberOfPeople = numberOfPeople;
    }

    public int getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(int phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @Override
    public String toString() {
        return name + reservationHour + reservationDate + numberOfPeople + phoneNumber;
    }
}
