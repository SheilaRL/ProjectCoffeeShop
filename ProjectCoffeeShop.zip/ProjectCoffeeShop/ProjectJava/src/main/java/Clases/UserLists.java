package Clases;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Class to store a list of users to work with it.
 * @author sheilaRodríguez.
 */
public class UserLists {

    /**
     * List atribute with constructor and getters and setters
     */
    private List<User> userList;

    private final String path = "src/users.txt";

    public UserLists() {
        this.userList = new ArrayList<>();
    }

    public List<User> getUserList() {
        return userList;
    }

    public void setUserList(List<User> userList) {
        this.userList = userList;
    }

    /**
     * Method to add users to the list
     */
    public void addUsers(User user) {
        userList.add(user);
    }

    /**
     * Method to delete users from the list
     */
    public void removeUser(User user) {
        userList.remove(user);
    }


    /**
     * Method to load users in my file txt
     */
    public void loadUsers()
    {
        userList.clear();

        try (BufferedReader myUsers = new BufferedReader(new FileReader(path));) {
            String line;
            while ((line = myUsers.readLine()) != null)
            {
                line = line.trim();
                System.out.println("Reading line: " + line);
                String[] parts = line.split(",");

                if (parts.length == 6) {
                    String name = parts[0];
                    String surname = parts[1];
                    String email = parts[2];
                    String password = parts[3];
                    String phoneNumber = parts[4];
                    String address = parts[5];

                    User user = new User(name, surname, email, password, phoneNumber, address);
                    userList.add(user);

                    System.out.println("User loaded:" + user);
                }

                else
                {
                    System.out.println("Invalid data format: " + line);
                }
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Method to save users in my file txt
     */
    public void saveUsers()
    {
        try (BufferedWriter myUsers = new BufferedWriter(new FileWriter(path))) {
            for (User user : userList) {
                myUsers.write(user.getName() + "," + user.getSurname() + "," + user.getEmail() + "," +
                        user.getPassword() + "," + user.getPhoneNumber() + "," + user.getAddress());
                myUsers.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}