package Clases;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

/**
 * Class to store information about products.
 * @author sheilaRodríguez.
 */

    public class Product
    {
        private int idProduct;
        private String productName;
        private double price;
        private int quantity;

        public Product(int idProduct, String productName, double price, int quantity) {
            this.idProduct = idProduct;
            this.productName = productName;
            this.price = price;
            this.quantity = quantity;
        }

        @Override
        public String toString()
        {
            return "Product ID: " + idProduct + "\n" +
                    "Product name: " + productName + "\n" +
                    "Product price: " + price + "\n" +
                    "Available stock: " + quantity;
        }


        public int getIdProduct() {
            return idProduct;
        }

        public void setIdProduct(int idProduct) {
            this.idProduct = idProduct;
        }

        public String getProductName() {
            return productName;
        }

        public void setProductName(String productName) {
            this.productName = productName;
        }

        public double getPrice() {
            return price;
        }

        public void setPrice(double price) {
            this.price = price;
        }

        public int getQuantity() {
            return quantity;
        }

        public void setQuantity(int quantity) {
            this.quantity = quantity;
        }
    }
